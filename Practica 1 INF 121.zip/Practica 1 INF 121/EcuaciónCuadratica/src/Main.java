public class Main {
    public static void main(String[] args) {
        double a = 2;
        double b = 5;
        double c = -3;

        EcuacionCuadratica ecuacion = new EcuacionCuadratica(a, b, c);
        double discriminante = ecuacion.getDiscriminante();

        if (discriminante > 0) {
            System.out.println("La ecuacion tiene dos raíces: " +
                    ecuacion.getRaiz1() + " y " + ecuacion.getRaiz2());
        } else if (discriminante == 0) {
            System.out.println("La ecuacion tiene una raíz: " + ecuacion.getRaiz1());
        } else {
            System.out.println("La ecuacion no tiene raíces reales");
        }
    }
}
