class Estadistica {
    private double[] datos;
    
    public Estadistica(double[] datos) {
        this.datos = datos;
    } 
    public double promedio() {
        double suma = 0;
        for (int i = 0; i < datos.length; i++) {
            suma += datos[i];
        }
        return suma / datos.length;
    } 
    public double desviacion() {
        double prom = promedio();
        double sumaCuadrados = 0; 
        for (int i = 0; i < datos.length; i++) {
            sumaCuadrados += (datos[i] - prom) * (datos[i] - prom);
        } 
        return Math.sqrt(sumaCuadrados / (datos.length - 1));
    }
}

