public class Main {
    public static void main(String[] args) {
   
        double[] numeros = {5, 8, 12, 3, 7, 9, 10, 6, 4, 11};
        Estadistica stats = new Estadistica(numeros);
        System.out.println("El promedio es " + stats.promedio());
        System.out.println("La desviacion estandar es " + stats.desviacion());
    }
}