public class Main {
    public static void main(String[] args) {
        double a = 1;
        double b = 2;
        double c = 3;
        double d = 4;
        double e = 5;
        double f = 6;
        EcuacionLineal ecuacion = new EcuacionLineal(a, b, c, d, e, f);
        if (ecuacion.tieneSolucion()) {
            System.out.println("x = " + ecuacion.getX() + ", y = " + ecuacion.getY());
        } else {
            System.out.println("La ecuacion no tiene solucion");
        }
    }
}
